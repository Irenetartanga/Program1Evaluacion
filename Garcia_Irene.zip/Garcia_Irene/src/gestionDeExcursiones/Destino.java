package gestionDeExcursiones;

public enum Destino {
	Montaña,
	Playa,
	Ciudad
	
}
